
''' 基础题 '''

# 1.已知字符串：“this is a test of Python”
# 	a.统计该字符串中字母s出现的次数: count()
# 	b.取出子字符串“test”, 用切片,不能数: 使用find(),len()
# 	c.采用不同的方式将字符串倒序输出: 切片，循环
# 	d.将其中的"test"替换为"exam" : replace

# 2.去掉字符串123@zh@qq.com中的@;
# 提示: replace



