# -*- encoding:utf-8 -*-

# 国家 = '中国'
c = '中国'
print(c)

# print c
# print 3!=4
# print 3<>4

# print(3<>4)

print(3/4)
print(3.0/4)
print(3//4)

# n = input('请输入一个数:')
# n = raw_input('请输入一个数:')
# print(n, type(n))

# x = 10
# y = "abc"
# print(x > y)

# Python3
# 0b  0o  0x
# Python2
# 八进制用 0
# print(016)

# short int long
# n = 2**100
# print(n, type(n))

print(list(range(10)))
# print(list(xrange(10)))

fp = open('a.txt', 'w')
# fp = file('a.txt', 'w')



