''''''
'''
1. with - as

2. csv文件

3. json模块
    json解析（json.loads）：JSON字符串=>JSON对象
    json序列化（json.dumps）：JSON对象=>JSON字符串
    
4. pickle模块
    将Python对象持久化
    pickle.dump() : Python对象=>文件
    pickle.load() : 文件=>Python对象

5. 冒泡排序
6. 选择排序

'''




