
place = '汶川'
age = 13

