

print(__name__)  # '__main__'


import module1

