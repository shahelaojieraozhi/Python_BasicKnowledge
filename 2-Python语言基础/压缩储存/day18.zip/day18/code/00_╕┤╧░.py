''''''
'''
1. 正则的方法
    match()
    search()
    findall()
    complie()
    
    finditer()
    split()
    sub()
    subn()
    
    group()
    groups()
    span()

2. 正则的符号
    表示单个字符
        .  
        []   [abc]   [a-z]  [3-5]
        \d  \D
        \w  \W
        \s  \S
        [^ ]
    表示数量
        ?
        *
        +
        {}   {3}  {2,5}  {2,}  {,5}
        *?
    表示边界
        ^  $ 
        \A  \Z
        \b  \B
    转义：
        \
    或：
        |
    分组： 
        ()
    分组别名:
        (?P<name> )
    非捕获性分组：
        (?: )
    
    
'''

