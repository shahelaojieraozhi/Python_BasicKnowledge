a=0o77
print(a|3)
print(a|3|7)
