L = [1,2,3,4,5]
print(','.join(str(n) for n in L))
