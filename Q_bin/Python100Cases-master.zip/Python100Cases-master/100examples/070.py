def lenofstr(s):
    return len(s)

print(lenofstr('tanxiaofengsheng'))
