s='zhangguang101'
print(len(s))
