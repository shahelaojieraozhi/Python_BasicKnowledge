i = ['a', 'b']
l = [1, 2]
print (dict(zip(i,l)))
