n=eval('0o'+str(int(input('八进制输入：'))))
print(n)
