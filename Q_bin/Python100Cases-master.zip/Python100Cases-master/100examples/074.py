a=[2,6,8]
b=[7,0,4]
a.extend(b)
a.sort()
print(a)
