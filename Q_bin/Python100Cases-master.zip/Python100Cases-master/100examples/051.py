a=0o77
print(a)
b=a&3
print(b)
b=b&7
print(b)
